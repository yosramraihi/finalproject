import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faThumbsUp, faThumbsDown, faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import './IdeaDetails.css';

const IdeaDetails = () => {
    const { id } = useParams();
    const [idea, setIdea] = useState(null);

    useEffect(() => {
        axios.get(`http://localhost:8000/api/ideas/${id}`)
            .then(res => setIdea(res.data))
            .catch(err => console.log(err));
    }, [id]);

    if (!idea) return <div>Loading...</div>;

    return (
        <div className="idea-details-container">
            <div className="card">
                <div className="card-body">
                    <div className="d-flex justify-content-between align-items-center mb-4">
                        <h1 className="text-primary">Idea Details</h1>
                        <Link to="/" className="btn btn-secondary">
                            <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
                            Back to Dashboard
                        </Link>
                    </div>
                    <h3 className="text-info">{idea.title}</h3>
                    <p>{idea.description}</p>
                    <p className="mb-2">Likes: {idea.likes}</p>
                    <div className="reactions">
                        <FontAwesomeIcon icon={faThumbsUp} className="me-2 text-success" />
                        <FontAwesomeIcon icon={faThumbsDown} className="me-2 text-danger" />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default IdeaDetails;

