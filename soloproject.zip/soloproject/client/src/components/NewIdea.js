import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import './NewIdea.css'; 

const NewIdea = () => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [errors, setErrors] = useState([]);
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        const newIdea = { title, description, username, email };
        axios.post('http://localhost:8000/api/ideas', newIdea)
            .then(() => {
                setTitle('');
                setDescription('');
                setUsername('');
                setEmail('');
                navigate('/');
            })
            .catch(err => {
                if (err.response && err.response.data.error) {
                    setErrors([err.response.data.error]);
                } else if (err.response && err.response.data.errors) {
                    const errorResponse = err.response.data.errors;
                    const errorArr = Object.values(errorResponse).map(error => error.message);
                    setErrors(errorArr);
                } else {
                    console.log(err);
                }
            });
    };

    return (
        <div className="new-idea-container">
            <div className="new-idea-card">
                <div className="d-flex justify-content-between align-items-center mb-4">
                    <h2>Create a New Idea</h2>
                    <Link to="/" className="btn btn-secondary">Go back home</Link>
                </div>
                {errors.length > 0 && (
                    <div className="alert alert-danger">
                        {errors.map((err, index) => (
                            <p key={index} className="mb-0">{err}</p>
                        ))}
                    </div>
                )}
                <form onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label htmlFor="title" className="form-label">Title</label>
                        <input
                            type="text"
                            id="title"
                            className="form-control"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            required
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="description" className="form-label">Description</label>
                        <textarea
                            id="description"
                            className="form-control"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            rows={4}
                            required
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="username" className="form-label">Username</label>
                        <input
                            type="text"
                            id="username"
                            className="form-control"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            required
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input
                            type="email"
                            id="email"
                            className="form-control"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>
                    <div className="text-center">
                        <button type="submit" className="btn btn-primary">Create Idea</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default NewIdea;


