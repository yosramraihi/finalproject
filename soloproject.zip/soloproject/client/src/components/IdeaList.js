import React from 'react';

const IdeaList = ({ ideas, handleDelete }) => {
    return (
        <table className="table">
            <thead className="thead-dark">
                <tr>
                    <th scope="col">Created At</th>
                    <th scope="col">Title</th>
                    <th scope="col">Description</th>
                    <th scope="col">Likes</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                {ideas.map(idea => (
                    <tr key={idea._id}>
                        <td>{new Date(idea.createdAt).toLocaleString()}</td>
                        <td>{idea.title}</td>
                        <td>{idea.description}</td>
                        <td>{idea.likes}</td>
                        <td>
                            <button className="btn btn-light" onClick={() => handleDelete(idea._id)}>Delete</button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
};

export default IdeaList;
