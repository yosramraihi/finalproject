import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faThumbsUp, faThumbsDown, faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import './Dashboard.css'; // Ensure correct path to your CSS file

const Dashboard = () => {
    const [ideas, setIdeas] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetchIdeas();
    }, []);

    const fetchIdeas = () => {
        axios.get('http://localhost:8000/api/ideas')
            .then(res => {
                const sortedIdeas = res.data.sort((a, b) => b.likes - a.likes);
                setIdeas(sortedIdeas);
            })
            .catch(err => console.log(err));
    };

    const handleDelete = (id) => {
        axios.delete(`http://localhost:8000/api/ideas/${id}`)
            .then(() => setIdeas(ideas.filter(idea => idea._id !== id)))
            .catch(err => console.log(err));
    };

    const handleLike = (id) => {
        axios.put(`http://localhost:8000/api/ideas/${id}/like`)
            .then(updatedIdea => {
                setIdeas(ideas.map(idea => idea._id === id ? updatedIdea.data : idea));
            })
            .catch(err => console.log(err));
    };

    const handleUnlike = (id) => {
        axios.put(`http://localhost:8000/api/ideas/${id}/unlike`)
            .then(updatedIdea => {
                setIdeas(ideas.map(idea => idea._id === id ? updatedIdea.data : idea));
            })
            .catch(err => console.log(err));
    };

    const UserProfileLink = ({ username }) => (
        <Link to={`/profile/${username}`} className="text-decoration-none">{username}</Link>
    );

    return (
        <div className="dashboard-container">
            <div className='title-container'>
                <h1 className="title">Bright Ideas</h1>
                <button className="btn btn-light" onClick={() => navigate('/new')}>Create a New Idea</button>
            </div>

            <h4>Discover and share bright ideas!</h4>
            {ideas.map(idea => (
                <div key={idea._id} className="card mb-3">
                    <div className="card-body">
                        <h5 className="card-title">
                            Posted by: <UserProfileLink username={idea.username} />
                        </h5>
                        <p className="card-text">{idea.description}</p>
                        <p className="card-text">Email: {idea.email}</p>
                        <div className="d-flex align-items-center">
                            <Link to={`/ideas/${idea._id}`} className="btn btn-link me-2">
                                <FontAwesomeIcon icon={faThumbsUp} /> {idea.likes}
                            </Link>
                            <button className="btn btn-success me-2" onClick={() => handleLike(idea._id)}>
                                <FontAwesomeIcon icon={faThumbsUp} /> Like
                            </button>
                            <button className="btn btn-danger" onClick={() => handleUnlike(idea._id)}>
                                <FontAwesomeIcon icon={faThumbsDown} /> Unlike
                            </button>
                            <button className="btn btn-light ms-auto" onClick={() => handleDelete(idea._id)}>
                                <FontAwesomeIcon icon={faTrashAlt} /> Delete
                            </button>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default Dashboard;
