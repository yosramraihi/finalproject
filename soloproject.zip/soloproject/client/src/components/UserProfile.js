import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './UserProfile.css'; // Assuming your CSS is in UserProfile.css

const UserProfile = () => {
    const { username } = useParams();
    const navigate = useNavigate();
    const [userData, setUserData] = useState(null);

    useEffect(() => {
        axios.get(`http://localhost:8000/api/users/${username}/details`)
            .then(res => {
                setUserData(res.data);
            })
            .catch(err => {
                console.error(err);
            });
    }, [username]);

    const goToDashboard = () => {
        navigate('/'); // Ensure '/dashboard' is a valid route in your application
    };

    if (!userData) return <div>Loading...</div>;

    return (
        <div className="profile-container">
            <h1>User Profile</h1>
            <p>Username: {userData.username} 😊</p>
            <p>Email: {userData.email} 📧</p>
            <p>Last Activity: {new Date(userData.lastActivity).toLocaleString()} 🕒</p>
            <p>Total Likes Received: {userData.totalLikesReceived} 👍</p>
            

            <button className="back-button" onClick={goToDashboard}>Back to Dashboard</button>
        </div>
    );
};

export default UserProfile;




