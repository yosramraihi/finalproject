import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import NewIdea from './components/NewIdea';
import IdeaDetails from './components/IdeaDetails';
import UserProfile from './components/UserProfile';


import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
    return (
        <Router>
            <div className="App">
              
                <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/new" element={<NewIdea />} />
                    <Route path="/ideas/:id" element={<IdeaDetails />}/>  
                    <Route path="/profile/:username" element={<UserProfile />} /> 
                                  
                </Routes>
            </div>
        </Router>
    );
}

export default App;


