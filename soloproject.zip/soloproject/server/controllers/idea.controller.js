const Idea = require('../models/idea.model');

// Fetch all ideas
const getAllIdeas = async (req, res) => {
    try {
        const ideas = await Idea.find();
        res.json(ideas);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Create a new idea
const createIdea = async (req, res) => {
    try {
        const { title, description, username, email } = req.body;
        const newIdea = new Idea({ title, description, username, email });
        await newIdea.save();
        res.status(201).json(newIdea);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};


const deleteIdea = async (req, res) => {
    try {
        const deletedIdea = await Idea.findByIdAndDelete(req.params.id);
        if (!deletedIdea) {
            return res.status(404).json({ error: 'Idea not found' });
        }
        res.json({ message: 'Idea deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


const likeIdea = async (req, res) => {
    try {
        const idea = await Idea.findByIdAndUpdate(
            req.params.id,
            { $inc: { likes: 1 } }, 
            { new: true } 
        );
        if (!idea) {
            return res.status(404).json({ error: 'Idea not found' });
        }
        res.json(idea);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


const unlikeIdea = async (req, res) => {
    try {
        const idea = await Idea.findByIdAndUpdate(
            req.params.id,
            { $inc: { likes: -1 } }, 
            { new: true } 
        );
        if (!idea) {
            return res.status(404).json({ error: 'Idea not found' });
        }
        res.json(idea);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


const getIdeaById = async (req, res) => {
    try {
        const idea = await Idea.findById(req.params.id);
        if (!idea) {
            return res.status(404).json({ error: 'Idea not found' });
        }
        res.json(idea);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

module.exports = {
    getAllIdeas,
    createIdea,
    deleteIdea,
    likeIdea,
    unlikeIdea,
    getIdeaById,
};
