const User = require('../models/user.model');
const Idea = require('../models/idea.model');

const getUserDetails = async (req, res) => {
    try {
        const { username } = req.params;
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        // Calculate total likes received
        const totalLikesReceived = await calculateTotalLikesReceived(username);
        res.json({
            username: user.username,
            email: user.email,
            lastActivity: user.lastActivity,
            totalLikesReceived: totalLikesReceived,
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Function to calculate total likes received
const calculateTotalLikesReceived = async (username) => {
    try {
        const ideas = await Idea.find({ username });
        return ideas.reduce((total, idea) => total + idea.likes, 0);
    } catch (err) {
        console.error(err);
        return 0;
    }
};

module.exports = {
    getUserDetails,
};

