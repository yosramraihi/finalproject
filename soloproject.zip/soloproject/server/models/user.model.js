const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    lastActivity: { type: Date, default: Date.now },
    totalLikesReceived: { type: Number, default: 0 }, // New field for total likes received
    // Other fields as needed
});

module.exports = mongoose.model('User', userSchema);
