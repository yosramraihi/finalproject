const IdeaController = require('../controllers/idea.controller');

module.exports = (app) => {
    app.get('/api/ideas', IdeaController.getAllIdeas);
    app.post('/api/ideas', IdeaController.createIdea);
    app.delete('/api/ideas/:id', IdeaController.deleteIdea);
    app.put('/api/ideas/:id/like', IdeaController.likeIdea);
    app.put('/api/ideas/:id/unlike', IdeaController.unlikeIdea);
    app.get('/api/ideas/:id', IdeaController.getIdeaById); 
};
