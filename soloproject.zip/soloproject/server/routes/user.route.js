// user.routes.js
const UserController = require('../controllers/user.controller');

module.exports = (app) => {
    app.get('/api/users/:username/details', UserController.getUserDetails);
};
